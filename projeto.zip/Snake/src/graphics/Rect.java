package graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

public class Rect extends Drawable{
	  
	  //private Point location;
	  //private Dimension dimension;
	  
	  private Rectangle rectangle;
	
	  public Rect() {
		  this.rectangle = new Rectangle(0,0);
	  }
	  
	  public Rect(Point location, Dimension dimension) {
		//this.location  = location;
		//this.dimension = dimension;
		  this.rectangle = new Rectangle(location, dimension);
	  }
	  
	  public Rect(int x, int y, int width, int heigth) {
		  //this.location  = new Point(x,y);
		  //this.dimension = new Dimension(width,heigth);
		  this.rectangle = new Rectangle(x,y,width,heigth);
	  }
	  
	  public Point getLocation() {
		return rectangle.getLocation();
	  }
	  
	  public void setLocation(Point location) {
		  rectangle.setLocation(location);
	  }

	  public Dimension getDimension() {
		return rectangle.getSize();
	  }
	  
	  public void setDimension(Dimension dimension) {
		  rectangle.setSize(dimension);
	  }
	  
	  public boolean intersects(Rect other) {
		  return rectangle.intersects(other.rectangle);
	  }

	  public void draw(Graphics g) {
		  g.fillRect((int)rectangle.getLocation().getX()
				    ,(int)rectangle.getLocation().getY() 
				    ,(int)rectangle.getSize().getWidth()
				    ,(int)rectangle.getSize().getHeight());
	  }
}
