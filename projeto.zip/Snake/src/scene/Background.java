package scene;

import graphics.Rect;
import util.Constants;

public class Background extends Rect{

	public Background() {
		super(0,0,Constants.WINDOW_WIDTH, Constants.WINDOW_HEIGHT);
		setColor(Constants.BACKGROUND_COLOR);
	}
}
